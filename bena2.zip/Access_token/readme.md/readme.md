
# Terraform Dynatrace Token Management

This Terraform configuration manages various Dynatrace token-related resources using modules. It includes:

- ActiveGate token settings
- ActiveGate token creation
- API token creation
- Global token settings

---

## Modules Overview

### 1. `dynatrace_activegate_token`
Manages ActiveGate token enforcement and expiration notification settings.

**Required API Token Scopes:**
- `settings.read`
- `settings.write`

**Example `tfvars` Configuration:**
```hcl
activegate_token_config = {
  auth_token_enforcement_manually_enabled = true
  expiring_token_notifications_enabled    = true
}
```

---

### 2. `dynatrace_ag_token`
Creates an ActiveGate token with a specified type, name, and expiration.

**Required API Token Scopes:**
- `activeGateTokenManagement.create`
- `activeGateTokenManagement.read`
- `activeGateTokenManagement.write`

**Example `tfvars` Configuration:**
```hcl
ag_token_config = {
  type            = "ENVIRONMENT"
  expiration_date = "now+3d"
  name            = "your_token_name"
}
```

---

### 3. `dynatrace_api_token`
Creates an API token with specified scopes and enablement status.

**Required API Token Scopes:**
- `apiTokens.read`
- `apiTokens.write`

**Example `tfvars` Configuration:**
```hcl
api_token_config = {
  name    = "your_token_name"
  enabled = true
  scopes  = ["DataExport", "ReadConfig", "WriteConfig"]
}
```

---

### 4. `dynatrace_token_settings`
Manages global token settings such as format and personal token allowance.

**Required API Token Scopes:**
- `settings.read`
- `settings.write`

**Example `tfvars` Configuration:**
```hcl
token_settings_config = {
  new_token_format = true
  personal_tokens  = false
}
```

---

##  Outputs

| Output Name        | Description                                      |
|--------------------|--------------------------------------------------|
| `activegate_token` | The full object of the ActiveGate token settings |
| `ag_token`         | The full object of the created AG token (sensitive) |
| `api_token`        | The full object of the created API token (sensitive) |
| `token_settings`   | The full object of the token settings configuration |

---

