# Dynatrace Terraform Module for Service-Level Objectives (SLO V3)

## Introduction
This repository contains a Terraform module for deploying and managing Service-Level Objectives (SLOs) in Dynatrace. The module is designed to simplify the configuration and lifecycle management of SLOs using Terraform.

## Requirements
- Terraform >= 0.12
- Dynatrace account

### Scopes
- **Read settings** (`settings.read`)
- **Write settings** (`settings.write`)
- **Read SLO** (`slo.read`)
- **Write SLO** (`slo.write`)

## Dynatrace Admin Module

<!-- BEGIN_TF_DOCS -->
#### Providers

| Name | Version |
|------|---------|
| <a name="provider_dynatrace"></a> [dynatrace](#provider_dynatrace) | ~> 1.0 |

#### Inputs

| Name | Description | Type |
|------|-------------|------|
| <a name="input_name"></a> [name](#input_name) | SLO name | `string` |
| <a name="input_enabled"></a> [enabled](#input_enabled) | Enable or disable the SLO | `bool` |
| <a name="input_custom_description"></a> [custom_description](#input_custom_description) | Custom description of the SLO | `string` |
| <a name="input_evaluation_type"></a> [evaluation_type](#input_evaluation_type) | Evaluation type (AGGREGATE) | `string` |
| <a name="input_evaluation_window"></a> [evaluation_window](#input_evaluation_window) | Timeframe for SLO evaluation (e.g., -1w) | `string` |
| <a name="input_filter"></a> [filter](#input_filter) | Entity selector filter | `string` |
| <a name="input_metric_expression"></a> [metric_expression](#input_metric_expression) | Metric expression used for SLO calculation | `string` |
| <a name="input_metric_name"></a> [metric_name](#input_metric_name) | Metric name | `string` |
| <a name="input_target_success"></a> [target_success](#input_target_success) | Target success threshold (%) | `number` |
| <a name="input_target_warning"></a> [target_warning](#input_target_warning) | Target warning threshold (%) | `number` |
| <a name="input_burn_rate_visualization_enabled"></a> [burn_rate_visualization_enabled](#input_burn_rate_visualization_enabled) | Enable burn rate visualization | `bool` |
| <a name="input_fast_burn_threshold"></a> [fast_burn_threshold](#input_fast_burn_threshold) | Threshold for fast burn rate | `number` |

#### Outputs

| Name | Description |
|------|-------------|
| <a name="output_slo_id"></a> [slo_id](#output_slo_id) | ID of the created Dynatrace SLO |
<!-- END_TF_DOCS -->

##  References

- [Dynatrace SLO Documentation](https://www.dynatrace.com/support/help/how-to-use-dynatrace/cloud-automation/service-level-objectives)
- [Dynatrace Settings API](https://www.dynatrace.com/support/help/dynatrace-api/environment-api/settings)
